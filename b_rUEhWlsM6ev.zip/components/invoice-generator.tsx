'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import { Toaster, toast } from 'sonner'
import html2canvas from 'html2canvas-pro'
import { jsPDF } from 'jspdf'
import { Header } from './header'
import { ClientForm } from './client-form'
import { DocumentDetailsForm } from './document-details-form'
import { LineItemsForm } from './line-items-form'
import { PricingSummary } from './pricing-summary'
import { NotesForm } from './notes-form'
import { DocumentPreview } from './document-preview'
import { ActionButtons } from './action-buttons'
import type { DocumentData, ClientInfo, LineItem } from '@/lib/types'
import {
  createDefaultDocument,
  loadDraft,
  saveDraft,
  generateDocumentNumber,
} from '@/lib/document-store'

export function InvoiceGenerator() {
  const [data, setData] = useState<DocumentData>(() => createDefaultDocument('invoice'))
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false)
  const previewRef = useRef<HTMLDivElement>(null)

  // Load draft on mount
  useEffect(() => {
    const draft = loadDraft()
    if (draft) {
      setData(draft)
      toast.info('Previous draft loaded')
    }
  }, [])

  // Auto-save draft every 30 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      saveDraft(data)
    }, 30000)
    return () => clearInterval(interval)
  }, [data])

  const handleTypeChange = useCallback((type: 'invoice' | 'quotation') => {
    setData((prev) => ({
      ...prev,
      type,
      documentNumber: generateDocumentNumber(type),
      notes:
        type === 'invoice'
          ? 'Payment is due within 30 days. Thank you for your business!'
          : 'This quotation is valid for 30 days from the date of issue.',
    }))
  }, [])

  const handleClientChange = useCallback((client: ClientInfo) => {
    setData((prev) => ({ ...prev, client }))
  }, [])

  const handleDocumentChange = useCallback((updates: Partial<DocumentData>) => {
    setData((prev) => ({ ...prev, ...updates }))
  }, [])

  const handleItemsChange = useCallback((items: LineItem[]) => {
    setData((prev) => ({ ...prev, items }))
  }, [])

  const handleGeneratePdf = async () => {
    if (!previewRef.current) return

    setIsGeneratingPdf(true)
    try {
      const element = previewRef.current.querySelector('#document-preview') as HTMLElement
      if (!element) {
        throw new Error('Preview element not found')
      }

      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff',
      })

      const imgWidth = 210 // A4 width in mm
      const pageHeight = 297 // A4 height in mm
      const imgHeight = (canvas.height * imgWidth) / canvas.width
      
      const pdf = new jsPDF('p', 'mm', 'a4')
      let heightLeft = imgHeight
      let position = 0

      pdf.addImage(canvas.toDataURL('image/png'), 'PNG', 0, position, imgWidth, imgHeight)
      heightLeft -= pageHeight

      while (heightLeft > 0) {
        position = heightLeft - imgHeight
        pdf.addPage()
        pdf.addImage(canvas.toDataURL('image/png'), 'PNG', 0, position, imgWidth, imgHeight)
        heightLeft -= pageHeight
      }

      const fileName = `${data.type === 'invoice' ? 'Invoice' : 'Quotation'}_${data.documentNumber}.pdf`
      pdf.save(fileName)
      toast.success('PDF downloaded successfully!')
    } catch (error) {
      console.error('Error generating PDF:', error)
      toast.error('Failed to generate PDF. Please try again.')
    } finally {
      setIsGeneratingPdf(false)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Toaster position="top-right" richColors />
      <Header documentType={data.type} onTypeChange={handleTypeChange} />

      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid gap-8 lg:grid-cols-2">
          {/* Form Section */}
          <div className="space-y-6">
            <ActionButtons
              data={data}
              onDataChange={setData}
              isGeneratingPdf={isGeneratingPdf}
              onGeneratePdf={handleGeneratePdf}
            />
            <DocumentDetailsForm data={data} onChange={handleDocumentChange} />
            <ClientForm client={data.client} onChange={handleClientChange} />
            <LineItemsForm items={data.items} onChange={handleItemsChange} />
            <PricingSummary
              items={data.items}
              discount={data.discount}
              vatRate={data.vatRate}
              onDiscountChange={(discount) => handleDocumentChange({ discount })}
              onVatRateChange={(vatRate) => handleDocumentChange({ vatRate })}
            />
            <NotesForm
              notes={data.notes}
              paymentDetails={data.paymentDetails}
              onNotesChange={(notes) => handleDocumentChange({ notes })}
              onPaymentDetailsChange={(paymentDetails) => handleDocumentChange({ paymentDetails })}
            />
          </div>

          {/* Preview Section */}
          <div className="lg:sticky lg:top-8 lg:h-fit">
            <h2 className="mb-4 text-lg font-semibold text-foreground">Live Preview</h2>
            <div className="overflow-auto rounded-lg shadow-lg">
              <DocumentPreview ref={previewRef} data={data} />
            </div>
          </div>
        </div>
      </main>

      {/* Print Styles */}
      <style jsx global>{`
        @media print {
          body * {
            visibility: hidden;
          }
          #document-preview,
          #document-preview * {
            visibility: visible;
          }
          #document-preview {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
          }
        }
      `}</style>
    </div>
  )
}
